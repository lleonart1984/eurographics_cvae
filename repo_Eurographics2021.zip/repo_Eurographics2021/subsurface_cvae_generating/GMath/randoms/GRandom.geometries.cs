﻿using System;
using System.Collections.Generic;
using System.Text;

using static GMath.Gfx;
using static GMath.GTools;

namespace GMath
{
    public partial class GRandom
    {
    }
}
